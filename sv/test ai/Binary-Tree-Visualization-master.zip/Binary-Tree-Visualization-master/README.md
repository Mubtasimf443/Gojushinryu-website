# Binary-Tree-Visualization
Binary-Tree-Visualization

[Live Demo](https://saliherdemk.github.io/Binary-Tree-Visualization/)

# Demo

<img src="https://github.com/saliherdemk/Binary-Tree-Visualization/blob/master/media/demo.gif" width="550" height="400">


